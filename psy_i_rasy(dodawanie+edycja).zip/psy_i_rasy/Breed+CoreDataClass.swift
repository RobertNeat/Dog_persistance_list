//
//  Breed+CoreDataClass.swift
//  psy_i_rasy
//
//  Created by apple on 27/05/2023.
//
//

import Foundation
import CoreData

@objc(Breed)
public class Breed: NSManagedObject {

}
